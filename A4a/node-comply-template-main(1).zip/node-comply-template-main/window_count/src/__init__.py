"""Reusable window-count source."""
