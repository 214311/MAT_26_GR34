"""Window-count analysis."""
